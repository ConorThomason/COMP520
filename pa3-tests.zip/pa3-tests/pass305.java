/**
 * COMP 520
 * Identification
 */
class Pass305 { 	
    public static void main(String[] args) {
        System.out.println(3);
    } 
}
