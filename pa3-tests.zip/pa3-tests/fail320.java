/*** line 11: duplicate declaration of class "Extra"
 * COMP 520
 * Identification
 */
class fail320 {
    int x;
}

class fail320 {
    // duplicate class
    int y; 
}
