/*** line 11: class "System" has already been declared
 * COMP 520
 * Identification
 */
class Fail322 {
    public static void main(String[] args) {
	System.out.println(5);
    }
}

class System {
    public int x;
}
