/**
 * COMP 520
 * Array and reference indexing
 */
class Pass330 {         

    public static void main(String[] args) {
	D [] da = new D[6];
	D d = da[3];
	int y = d.x;
    }
}

class D { public int x; }


