/**
 * COMP 520
 * Identification
 */
class Pass324 {         
    public static void main(String[] args) {
        Pass324 p = new Pass324();
        int x = p.p() + p.x;
    }
    
    public int x;
    
    public int p() {
        return 3;
    }
}
