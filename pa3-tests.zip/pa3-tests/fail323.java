/*** line 11: solitary variable declaration statement not permitted here
 * COMP 520
 * Identification
 */
class Fail323 { 	
    public static void main(String[] args) {
	int x = 0;
	if (3 > 4) 
	    x = 1;
	else
	    int y = 2;
    }
}

