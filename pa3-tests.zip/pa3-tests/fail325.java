/*** line 7: binary operator "!=" requires arguments to have the same type.
 * COMP 520
 * Type checking
 */
class Fail325 {
    public static void main(String [] args) {
	boolean b = 15 + 7 != true;
    }
}
