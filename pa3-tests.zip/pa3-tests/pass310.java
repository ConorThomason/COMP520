/**
 * COMP 520
 * Array creation
 */
class Pass310 {
   public static void main (String [] args) {

      int aa_length = 4;
      int [] aa = new int [aa_length];
   }
}
