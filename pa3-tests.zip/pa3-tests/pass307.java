/*
 * COMP 520
 * Identification
 */
class Pass307 {

}

class A { 	

    public void foo(A A) { }  // A may have both definitions in the same scope
}
