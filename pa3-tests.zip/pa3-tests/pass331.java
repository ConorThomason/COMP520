/**
 * COMP 520
 * Array indexing
 */
class Pass331 {         

    public D [] d; 

    public void foo() {
	d = new D[10];
    }
}

class D { public int x; }


