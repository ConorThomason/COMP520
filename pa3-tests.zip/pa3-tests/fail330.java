/*** line 9: solitary variable declaration statement not permitted here
 * COMP 520
 * Identification
 */
class fail330 { 	
	public static void main(String[] args) {
		int x = 0;
		while (3 > 4) 
			int y = 2;
	}
}
