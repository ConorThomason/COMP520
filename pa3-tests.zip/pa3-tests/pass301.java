/**
 * COMP 520
 * main method Identification
 */
class Pass301 { 	
    public static void main(String[] args) {} 
}
