/**
 * COMP 520
 * Identification
 */
class Pass327 { 	

    private int x;

    public void set(int y) {
	int x = y;
	this.x = x;
    }
}
