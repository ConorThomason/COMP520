/*** line 8: identifier "this" does not denote a method
 * COMP 520
 * Identification
 */
class Fail337 {         

    public void p() {
        this();
    }
}

