/*** line 7: duplicate declaration of member "foo" 
 * COMP 520
 * Identification
 */
class fail302 {

    public int foo;
    private void foo() {}
}
