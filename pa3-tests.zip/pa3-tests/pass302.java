/**
 * COMP 520
 * Identification
 */
class pass302 { 	
    
    A02 a;
}

class A02 {

    int x;
}

