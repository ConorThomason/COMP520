/*** 
 * COMP 520
 * Identification - static method invocation
 */
class Pass308 {         
    public static void main(String[] args) {
        int x = foo(20);
    }
    
    public static int foo(int parm) {
        return 50;
    }
}
