/*** line 9: member "x" has duplicate declaration(s) in class "Fail321"
 * COMP 520
 * Identification
 */
class Fail321 {

    public int x;
    
    private int x;
}
