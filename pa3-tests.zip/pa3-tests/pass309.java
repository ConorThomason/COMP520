/*** 
 * COMP 520
 * Identification - static member access
 */
class Pass309 { 	
    public static void main(String[] args) {
    	int z = x;
    }
    
    public static int x;
}
