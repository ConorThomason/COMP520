/*** line 8: binary operator "+" expecting "int" type, received "boolean" type
 * COMP 520
 * Type Checking
 */
class fail311 {

    public int f() {
	return 1 + (2 < 3);
    }
}
