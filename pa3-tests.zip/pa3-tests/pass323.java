/**
 * COMP 520
 * Identification
 */
class Pass323 { 	
    public static void main(String[] args) {
        int A11 = 3;
    } 

    public A11 a;
    
    private int foo(int A11) { // ok 
        return A11;
    }
}

class A11 {
    public int x;
}
