/**
 * COMP 520
 * Identification
 */
class Pass328 {         

    public static void main(String[] args) {

        boolean p = true;
        int x = 3;

        if (p) {
            int y = 5;
        }
        else
            x = 4;

        System.out.println(x);
    }
}
