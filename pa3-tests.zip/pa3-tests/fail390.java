/*** line 9: class "Missing" has no declaration
 * COMP 520
 * Identification
 */
class Fail301 {

    int x;

    Missing c;
}

