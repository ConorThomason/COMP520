/*** line 7: incompatible types in assignment statement 
 * COMP 520
 * Type checking
 */
class Fail326 { 
    public static void main(String [] args) { 
	C2 c = new C1(); 
    }
}

class C1 { }

class C2 { }
