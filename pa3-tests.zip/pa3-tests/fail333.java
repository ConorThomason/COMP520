/*** line 9: member "x" has duplicate declaration in class "Fail333"
 * COMP 520
 * Identification
 */
class Fail333 {

    public int x;
    
    public void x() {}
}
