/*** line 11: reference "Testclass" does not denote a field or a variable
 * COMP 520
 * Identification
 */
class TestClass {
                
    public static void staticContext() {

        TestClass t = null;

        t = TestClass;
    }
}
