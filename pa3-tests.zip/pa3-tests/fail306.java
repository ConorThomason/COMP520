/*** line 10: identifier "z" has not been declared
 * COMP 520
 * Identification
 */
class fail306 { 	

    int y;

    public void foo() {
	int x = y + z;
    }
}

