/***  line 8: parameter "x" is already declared in method "foo"
 * COMP 520
 * Identification
 */
class fail308{ 	


    public void foo(int x, int x) {}
}

