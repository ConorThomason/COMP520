/**
 * COMP 520
 * Array indexing
 */
class Pass332 {         

    public D [] d; 

    public void foo() {
	D p  = this.d[3];
	int y = p.x;
    }
}

class D { public int x; }


