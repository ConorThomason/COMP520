/**
 * COMP 520
 * Identification
 */
class Pass304 {         
    public static void main(String[] args) {} 

    public void foo(Pass304 x) {
        int Pass304 = 3; 
        Pass304 y = x;   /* not hidden */

    }
}
