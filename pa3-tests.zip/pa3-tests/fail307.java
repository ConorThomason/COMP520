/***  line 10: undeclared class "weird"
 * COMP 520
 * Identification
 */
class fail307 { 	


    public void weird() { }

    public void foo(weird x) { }
}

