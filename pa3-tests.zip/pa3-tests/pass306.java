/**
 * COMP 520
 * Identification
 */
class Pass306 {

    int C;  // does not hide class C 

    C c;    // OK
}

class C {
    int x;
}
