/*** line 7: reference "F02" is not a variable
 * COMP 520
 * Identification
 */
class fail335 { 	
    public static void main(String[] args) {
        F02 c = F02;
    }
}

class F02 {
    public int x;
}
