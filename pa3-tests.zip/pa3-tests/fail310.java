/*** line 7: expression yields an unsupported type  
 * COMP 520
 * Type checking
 */
class fail310 { 	
    public static void main(String [] args) {
		System.out.println(args[0]);
	}
}
