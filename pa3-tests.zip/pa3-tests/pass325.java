/**
 * COMP 520
 * Identification
 */
class Pass325 {

    private void Foo() {
	Foiled.back.mine = 3;
    }
	
    public static int mine;
}


class Foiled {

    public static void main(String[] args) {}

    static Pass325 back;
}
