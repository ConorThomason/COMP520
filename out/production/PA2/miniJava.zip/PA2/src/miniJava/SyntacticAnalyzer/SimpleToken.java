package miniJava.SyntacticAnalyzer;

public enum SimpleToken{
    BINOP, UNOP;
}