// PA2 fail stmt
class A {
    private void f(){
        a[3]();
    }
}
