// PA2 unary and binop precedence
class Unprecedented {
    void p(){
        int x = -1 + 2 * 3 / 4 > 5 >= 6 < 7 <= - -8 != 9 && !!false || true + new Unprecedented();
    }
}

