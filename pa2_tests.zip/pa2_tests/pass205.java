// PA2 pass parameter decl
class A {
    void p(A [ ] s){}
}
