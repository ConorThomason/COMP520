// PA2 method decl pass
class Foo {
    private void x(){}
}
