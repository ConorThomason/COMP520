// PA2 member decl fail
class Foo {
    private int x = 3;
}
