// PA1 parse decl pass
class Test {

    void p() {
	int a = 3;
	int [] b = new int[4];
    }
}

