// PA2 field decl fail
class Foo {
    private void x;
}
