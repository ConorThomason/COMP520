// PA1 parse ref expr fail
class Test {
   void main () {
       this.id.this = this.id.this;
   }
}
