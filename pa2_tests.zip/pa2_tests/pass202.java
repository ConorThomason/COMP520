// PA2 pass method decl
class A {
    static void p(){}
}
