//  PA2 pass expr precedence
class A { 
    int f() { 
        boolean x = true && false || true; 
    } 
}
