// PA2 fail NewExpr
class Foo {

    void f() {
	x = new Foo(3);
    }
}
