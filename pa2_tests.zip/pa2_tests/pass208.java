// PA2 pass qualified ref method invocation
class A {
    void p(){
        x.y(3);
    }
}
