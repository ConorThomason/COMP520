//  PA2 pass expr precedence
class A { 
    int f ( ) { 
        int x = 1 + 2 - 3 * 4 / 5 ; 
    } 
}
