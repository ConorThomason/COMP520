// PA1 parse call pass
class Test {

    void p(int a) {
	C c = new C();
	c.p(2,3);
    }
}

