// PA1 lex comment fail
class IllegalComment {
   public static void main (String [] args) {
   } // nothing follows final *
}/* ****