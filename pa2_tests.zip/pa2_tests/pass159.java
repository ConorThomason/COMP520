// PA1 parse refs pass
class Test {

    int [] a;
    Test [] t;

    int p() {
        t[e] = this + 1;
    }
}

