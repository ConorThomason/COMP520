// PA1 parse refs pass
class Test {

    void p() {
        A a = 23;
	boolean b = c;
    }
}

