//  PA2 pass references
class T {
    void foo() {
	foo(4);
        this.foo(5);
        return p[3] + a.b;
    }
}
