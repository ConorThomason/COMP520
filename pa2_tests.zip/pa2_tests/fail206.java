// PA2 member decl fail
class Foo {
    boolean [] z;
}
