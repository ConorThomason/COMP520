// PA1 parse stmt fail
class IllegalStmt {
   void main () {
       this;
   }
}
