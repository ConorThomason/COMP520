//PA2 pass qualified reference assignment
class A {
    void p(){
        x[2] = 3;
    }
}
