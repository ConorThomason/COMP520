// PA1 parse decl pass
class Test {

    void p(int a) {
        Test [ ]  v = a;
    }
}

