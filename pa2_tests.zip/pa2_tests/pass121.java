// PA1 lex unop pass
class id {
    void p(){
        int x =  - b;
        boolean y = !y;
    }
}

