// PA2 fail NewExpr
class Foo {

    void f() {
	x = new int 5;
    }
}
