// PA1 parse keywd fail
class LValueFail {
   void foo () {
      true = false;
   }
}
