// PA2 member decl fail
class Foo {
    true x;
}
