// PA2 fail IxExpr
class Foo {

    void f() {
	x = a.b.c[2][3];
    }
}
