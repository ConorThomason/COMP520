// PA1 parse unop fail
class IllegalExpressions {
   void foo() {
      z = a!b;
   }
}
