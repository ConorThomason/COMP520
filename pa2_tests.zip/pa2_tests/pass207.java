// PA2 pass new expr
class A {
    void p(){
        A a = new A();
    }
}
