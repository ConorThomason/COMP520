// PA2 pass indexedRef
class A {
    void p(){
        A x = x[3];
    }
}
