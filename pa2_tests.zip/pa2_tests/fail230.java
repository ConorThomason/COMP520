// PA2 fail reference
class A {
    void p(){  x = a.this; }
}
