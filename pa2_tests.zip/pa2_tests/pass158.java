// PA1 parse refs pass
class Test {

    void p() {
        a = true;
        a [b] = c;
        p ();
        a.b = d;
        c.p(e);
    }
}

