// PA1 parse expr fail
class IllegalExpressions {
   void main () {
      z = a+!=b;
   }
}
