// PA1 parse method param type fail
class Illegal {
    void foo (void x) {
	x = 1;
   }
}
