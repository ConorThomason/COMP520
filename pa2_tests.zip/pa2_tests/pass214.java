// PA2 pass qualified reference
class A {
    void p(){
        A x = this.p();
    }
}
