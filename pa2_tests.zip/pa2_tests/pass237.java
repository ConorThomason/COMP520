// PA2 fail indexed ref
class A {
    void p(){
        A x = this[3];
    }
}
